<?php
/**
 * 文章置顶（针对林海草原移植的simpleblog主题样式而定制） 
 * 
 * Mod by <a href="https://lhcy.org">林海草原</a>
 * @package Sticky
 * @author 林海草原, Ryan, Willin Kan
 * @version 1.0.2
 * @update: 2025.8.8
 * @link https://lhcy.org
 */
class Sticky_Plugin implements Typecho_Plugin_Interface
{
    public static function activate()
    {
        Typecho_Plugin::factory('Widget_Archive')->indexHandle = array('Sticky_Plugin', 'sticky');
        Typecho_Plugin::factory('Widget_Archive')->categoryHandle = array('Sticky_Plugin', 'stickyC');
    }

    public static function deactivate(){}
    
    public static function config(Typecho_Widget_Helper_Form $form)
    {
        $sticky_cids = new Typecho_Widget_Helper_Form_Element_Text(
          'sticky_cids', NULL, '',
          '置顶文章的 cid', '按照排序输入, 请以半角逗号或空格分隔 cid.');
        $form->addInput($sticky_cids);

        $sticky_html = new Typecho_Widget_Helper_Form_Element_Textarea(
            'sticky_html', 
            NULL, 
            '<div class="sticky-arrow"></div>', // 默认值改成你的 sticky-arrow
            '置顶标记的 HTML', 
            '这段代码会自动插入置顶文章的标题前（支持自定义 HTML）'
        );
        $sticky_html->input->setAttribute('rows', '7')->setAttribute('cols', '80');
        $form->addInput($sticky_html);
        
        $sticky_cat = new Typecho_Widget_Helper_Form_Element_Radio('sticky_cat' , array('1'=>_t('开启'),'0'=>_t('关闭')),'1',_t('分类置顶'),_t('开启分类页面也会把文章置顶'));
        $form->addInput($sticky_cat);
    }

    public static function personalConfig(Typecho_Widget_Helper_Form $form){}

    public static function sticky($archive, $select)
    {
        $config  = Typecho_Widget::widget('Widget_Options')->plugin('Sticky');
        $sticky_cids = $config->sticky_cids ? explode(',', strtr($config->sticky_cids, ' ', ',')) : '';
        if (!$sticky_cids) return;

        $db = Typecho_Db::get();
        $paded = $archive->request->get('page', 1);

        foreach($sticky_cids as $cid) {
          if ($cid && $sticky_post = $db->fetchRow($archive->select()->where('cid = ?', $cid))) {
              if ($paded == 1) {                               // 首頁 page.1 才會有置頂文章
                $sticky_post['title'] = $config->sticky_html . $sticky_post['title']; // 修改这里：sticky_html 放在前面
                $archive->push($sticky_post);                  // 選取置頂的文章先壓入
              }
              $select->where('table.contents.cid != ?', $cid); // 使文章不重覆
          }
        }
    }

    public static function stickyC($archive, $select)
    {
        $config  = Typecho_Widget::widget('Widget_Options')->plugin('Sticky');
        if (!$config->sticky_cat) return;
        $sticky_cids = $config->sticky_cids ? explode(',', strtr($config->sticky_cids, ' ', ',')) : '';
        if (!$sticky_cids) return;

        $db = Typecho_Db::get();
        $paded = $archive->request->get('page', 1);

        foreach($sticky_cids as $cid) {
          if ($cid && $sticky_post = $db->fetchRow($archive->select()->where('cid = ?', $cid))) {
              if ($paded == 1) {                               // 首頁 page.1 才會有置頂文章
                $sticky_post['title'] = $config->sticky_html . $sticky_post['title']; // 修改这里：sticky_html 放在前面
                $archive->push($sticky_post);                  // 選取置頂的文章先壓入
              }
              $select->where('table.contents.cid != ?', $cid); // 使文章不重覆
          }
        }
    }
}